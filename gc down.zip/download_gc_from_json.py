#!/usr/bin/env python3
"""Download files listed in G&C_Master_20261111_links.json."""

import argparse
import json
import re
import sys
import time
from pathlib import Path

import requests

SCRIPT_DIR = Path(__file__).resolve().parent
DEFAULT_JSON = SCRIPT_DIR / "G&C_Master_20261111_links.json"
DEFAULT_OUT = SCRIPT_DIR / "G&C_Master_20261111_downloads"
DEFAULT_UA = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/131.0.0.0 Safari/537.36"
)

CHROME_HEADERS = {
    "User-Agent": DEFAULT_UA,
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "image/avif,image/webp,application/pdf,*/*;q=0.8"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "sec-ch-ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"macOS"',
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Upgrade-Insecure-Requests": "1",
    "Connection": "keep-alive",
    "Referer": "https://www.ia.org.hk/",
}


def safe_component(value):
    cleaned = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", str(value)).strip(" .")
    return cleaned or "unnamed"


def parse_args():
    parser = argparse.ArgumentParser(description="Download G&C filename links with Chrome-like requests.")
    parser.add_argument("--json", type=Path, default=DEFAULT_JSON, help="Path to the extracted links JSON.")
    parser.add_argument("--out", type=Path, default=DEFAULT_OUT, help="Directory to save downloaded files.")
    parser.add_argument("--limit", type=int, default=0, help="Download only the first N items; 0 means all.")
    parser.add_argument("--timeout", type=float, default=30.0, help="Per-request timeout in seconds.")
    parser.add_argument("--force", action="store_true", help="Overwrite files that already exist.")
    parser.add_argument("--cookie", help="Full Cookie header from a browser that passed Cloudflare.")
    parser.add_argument("--cookie-file", type=Path, help="File containing the Cookie header; preferred over --cookie.")
    parser.add_argument("--user-agent", default=DEFAULT_UA, help="Must match the browser that produced the Cookie.")
    parser.add_argument("--delay", type=float, default=0.0, help="Seconds to wait between downloads.")
    return parser.parse_args()


def main():
    args = parse_args()
    payload = json.loads(args.json.read_text(encoding="utf-8"))
    items = payload["items"]
    if args.limit > 0:
        items = items[:args.limit]

    args.out.mkdir(parents=True, exist_ok=True)
    session = requests.Session()
    session.headers.update(CHROME_HEADERS)
    session.headers["User-Agent"] = args.user_agent

    cookie = args.cookie
    if args.cookie_file:
        cookie = args.cookie_file.read_text(encoding="utf-8").strip()
    if cookie:
        session.headers["Cookie"] = cookie

    ok = skipped = failed = 0
    failures = []

    for item in items:
        url = item["url"]
        sheet_dir = args.out / safe_component(item["sheet"])
        filename = f"{int(item['row']):04d}_{safe_component(item['download_name'])}"
        target = sheet_dir / filename
        if target.exists() and not args.force:
            print(f"SKIP exists {target}")
            skipped += 1
            continue

        sheet_dir.mkdir(parents=True, exist_ok=True)
        tmp = target.with_name(target.name + ".part")
        try:
            with session.get(url, timeout=args.timeout, stream=True) as response:
                content_type = response.headers.get("Content-Type", "").split(";")[0].strip().lower()
                if content_type == "text/html":
                    preview = next(response.iter_content(1024), b"").decode("utf-8", "replace")
                    if "Just a moment" in preview or "cf-challenge" in preview:
                        raise RuntimeError(
                            "Cloudflare challenge; supply a browser Cookie header containing cf_clearance "
                            "via --cookie-file and keep --user-agent matched to that browser"
                        )
                    response.raise_for_status()
                    raise RuntimeError(f"got HTML instead of document ({content_type})")
                response.raise_for_status()
                with tmp.open("wb") as fh:
                    for chunk in response.iter_content(chunk_size=65536):
                        if chunk:
                            fh.write(chunk)
            tmp.replace(target)
            print(f"OK {item['id']} -> {target}")
            ok += 1
        except Exception as exc:
            if tmp.exists():
                tmp.unlink()
            failed += 1
            failures.append({"id": item["id"], "url": url, "error": str(exc)})
            print(f"FAIL {item['id']}: {exc}", file=sys.stderr)

        if args.delay > 0:
            time.sleep(args.delay)

    print(f"done: ok={ok} skipped={skipped} failed={failed} out={args.out}")
    if failures:
        report = args.out / "download_failures.json"
        report.write_text(json.dumps(failures, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"failures: {report}", file=sys.stderr)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
