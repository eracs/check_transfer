#!/usr/bin/env python3
"""校验指定 folder 下的文件是否覆盖 4 个文档清单中引用的所有文件。

- 递归扫描 folder（含子文件夹），按文件名匹配（不区分大小写、忽略全/半角差异）
- 缺失文件写入 Markdown 报告，并注明来自哪个清单文件 / sheet / 行号
- 非文件名条目（如 "Attachment: Annex"）单独列出，需人工核对

依赖: 无（仅标准库）。需先运行 extract_filenames.py 生成 JSON。

用法:
    python3 check_missing_files.py /path/to/documents
    python3 check_missing_files.py /path/to/documents --json-dir ./filenames --out ./missing_files.md
"""

from __future__ import annotations

import argparse
import json
import os
import re
import unicodedata
from collections import OrderedDict
from datetime import datetime
from pathlib import Path

WORKBOOK_ORDER = ["bea_sek", "citi_sek", "bnc_ifa", "gc"]


def normalize(name: str) -> str:
    """NFKC 归一化（全角->半角）+ 空白折叠 + 小写，用于宽松匹配。"""
    text = unicodedata.normalize("NFKC", name)
    text = re.sub(r"\s+", " ", text).strip()
    return text.casefold()


def scan_folder(folder: Path) -> tuple[dict[str, list[str]], dict[str, list[str]]]:
    exact: dict[str, list[str]] = {}
    stems: dict[str, list[str]] = {}
    for root, dirs, files in os.walk(folder):
        dirs[:] = [d for d in dirs if d not in {".git", ".svn"}]
        for filename in files:
            if filename in {".DS_Store", "Thumbs.db"}:
                continue
            rel = str(Path(root, filename).relative_to(folder))
            norm = normalize(filename)
            exact.setdefault(norm, []).append(rel)
            stems.setdefault(Path(norm).stem, []).append(rel)
    return exact, stems


def md_escape(text: str | None) -> str:
    if not text:
        return ""
    return str(text).replace("|", "\\|").replace("\r", " ").replace("\n", " ")


def load_entries(json_dir: Path) -> list[dict]:
    payloads = []
    for path in sorted(json_dir.glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            print(f"[WARN] 跳过无法解析的 JSON: {path} ({exc})")
            continue
        if not isinstance(data, dict) or "entries" not in data:
            continue
        payloads.append(data)

    def order(item: dict) -> tuple[int, str]:
        key = item.get("workbook_key", "")
        return (WORKBOOK_ORDER.index(key) if key in WORKBOOK_ORDER else len(WORKBOOK_ORDER), key)

    return [p for p in sorted(payloads, key=order)]


def check(folder: Path, json_dir: Path, out_path: Path) -> int:
    payloads = load_entries(json_dir)
    if not payloads:
        print(f"[FAIL] {json_dir} 下没有可用的 JSON，请先运行 extract_filenames.py")
        return 2

    exact, stems = scan_folder(folder)
    total_scanned = sum(len(v) for v in exact.values())

    rows_summary: list[dict] = []
    missing_groups: "OrderedDict[tuple[str, str], list[dict]]" = OrderedDict()
    reference_groups: "OrderedDict[tuple[str, str], list[dict]]" = OrderedDict()
    alt_ext_groups: "OrderedDict[tuple[str, str], list[dict]]" = OrderedDict()

    for payload in payloads:
        workbook = payload.get("workbook", "")
        by_list: dict[str, dict] = {}
        for entry in payload.get("entries", []):
            list_name = entry.get("list", "")
            stats = by_list.setdefault(
                list_name,
                {"refs": 0, "distinct": set(), "found": set(), "missing": set(), "reference": 0},
            )
            stats["refs"] += 1
            name = entry["file"]
            norm = normalize(name)

            if entry.get("kind") != "file":
                stats["reference"] += 1
                reference_groups.setdefault((workbook, list_name), []).append(entry)
                continue

            stats["distinct"].add(norm)

            if norm in exact:
                stats["found"].add(norm)
            elif Path(norm).stem in stems:
                stats["found"].add(norm)
                alt = dict(entry)
                alt["found_at"] = stems[Path(norm).stem]
                alt_ext_groups.setdefault((workbook, list_name), []).append(alt)
            else:
                stats["missing"].add(norm)
                missing_groups.setdefault((workbook, list_name), []).append(entry)

        for list_name, stats in by_list.items():
            rows_summary.append(
                {
                    "workbook": workbook,
                    "list": list_name,
                    "refs": stats["refs"],
                    "distinct": len(stats["distinct"]),
                    "found": len(stats["found"]),
                    "missing": len(stats["missing"]),
                    "reference": stats["reference"],
                }
            )

    # 同一文件可能被多处引用：按文件名去重，保留全部来源
    def dedupe(entries: list[dict]) -> "OrderedDict[str, dict]":
        result: "OrderedDict[str, dict]" = OrderedDict()
        for entry in entries:
            key = normalize(entry["file"])
            if key not in result:
                result[key] = {"file": entry["file"], "sources": []}
            result[key]["sources"].append(entry)
        return result

    lines: list[str] = []
    lines.append("# COEUS 文档完整性检查报告")
    lines.append("")
    lines.append(f"- 检查时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"- 目标文件夹：`{folder}`")
    lines.append(f"- 对照清单目录：`{json_dir}`")
    lines.append(f"- 递归扫描到文件数：{total_scanned}")
    lines.append("")
    lines.append("## 汇总")
    lines.append("")
    lines.append("| 清单文件 | Sheet | 引用条目 | 文件名去重 | 已找到 | 缺失 | 非文件名条目 |")
    lines.append("|---|---|---:|---:|---:|---:|---:|")
    totals = {"refs": 0, "distinct": 0, "found": 0, "missing": 0, "reference": 0}
    for row in rows_summary:
        for k in totals:
            totals[k] += row[k]
        flag = " ❌" if row["missing"] else ""
        lines.append(
            f"| {md_escape(row['workbook'])} | {md_escape(row['list'])} | {row['refs']} | "
            f"{row['distinct']} | {row['found']} | {row['missing']}{flag} | {row['reference']} |"
        )
    lines.append(
        f"| **合计** | | **{totals['refs']}** | **{totals['distinct']}** | "
        f"**{totals['found']}** | **{totals['missing']}** | **{totals['reference']}** |"
    )
    lines.append("")

    lines.append("## 缺失文件")
    lines.append("")
    if not missing_groups:
        lines.append("未发现缺失文件。")
        lines.append("")
    else:
        lines.append("> 匹配规则：按文件名递归匹配（不区分大小写，忽略全/半角差异）。")
        lines.append("")
        for (workbook, list_name), entries in missing_groups.items():
            deduped = dedupe(entries)
            lines.append(f"### `{workbook}` / `{list_name}`（缺失 {len(deduped)} 个）")
            lines.append("")
            lines.append("| # | 文件名 | 来源行号 | 文档编号 | 文档标题 |")
            lines.append("|---:|---|---|---|---|")
            for idx, item in enumerate(deduped.values(), 1):
                rows = ", ".join(str(s["row"]) for s in item["sources"])
                codes = ", ".join(sorted({s["doc_code"] for s in item["sources"] if s.get("doc_code")})) or "—"
                titles = "; ".join(
                    dict.fromkeys(md_escape(s.get("title")) for s in item["sources"] if s.get("title"))
                ) or "—"
                lines.append(f"| {idx} | {md_escape(item['file'])} | {rows} | {md_escape(codes)} | {titles} |")
            lines.append("")

    lines.append("## 非文件名条目（无法自动校验，需人工核对）")
    lines.append("")
    if not reference_groups:
        lines.append("无。")
        lines.append("")
    else:
        lines.append("> 这些条目的值不是带扩展名的文件名（如法规编号、附件说明），需人工确认对应文件。")
        lines.append("")
        for (workbook, list_name), entries in reference_groups.items():
            lines.append(f"### `{workbook}` / `{list_name}`（{len(entries)} 条）")
            lines.append("")
            lines.append("| # | 原始值 | 行号 | 文档标题 |")
            lines.append("|---:|---|---|---|")
            for idx, entry in enumerate(entries, 1):
                lines.append(
                    f"| {idx} | {md_escape(entry['file'])} | {entry['row']} | "
                    f"{md_escape(entry.get('title')) or '—'} |"
                )
            lines.append("")

    lines.append("## 已找到但扩展名不同（供参考）")
    lines.append("")
    if not alt_ext_groups:
        lines.append("无。")
        lines.append("")
    else:
        for (workbook, list_name), entries in alt_ext_groups.items():
            lines.append(f"### `{workbook}` / `{list_name}`（{len(entries)} 条）")
            lines.append("")
            lines.append("| # | 清单中的文件名 | 实际找到 | 行号 |")
            lines.append("|---:|---|---|---|")
            for idx, entry in enumerate(entries, 1):
                found = "; ".join(entry.get("found_at", []))
                lines.append(f"| {idx} | {md_escape(entry['file'])} | {md_escape(found)} | {entry['row']} |")
            lines.append("")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines), encoding="utf-8")
    print(
        f"[DONE] 引用 {totals['refs']} 条 / 去重 {totals['distinct']} 个；"
        f"找到 {totals['found']}，缺失 {totals['missing']}，非文件名 {totals['reference']}"
    )
    print(f"报告已写入: {out_path}")
    return 0 if totals["missing"] == 0 else 1


def main() -> int:
    script_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="检查 folder 下的文件是否覆盖文档清单中的所有引用文件")
    parser.add_argument("folder", type=Path, help="待检查的文件夹（会递归扫描子文件夹）")
    parser.add_argument(
        "--json-dir",
        type=Path,
        default=script_dir / "filenames",
        help="extract_filenames.py 输出的 JSON 目录 (默认: ./filenames)",
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=script_dir / "missing_files.md",
        help="Markdown 报告输出路径 (默认: ./missing_files.md)",
    )
    args = parser.parse_args()

    folder = args.folder.expanduser().resolve()
    if not folder.is_dir():
        print(f"[FAIL] 文件夹不存在: {folder}")
        return 2
    return check(folder, args.json_dir.expanduser().resolve(), args.out.expanduser().resolve())


if __name__ == "__main__":
    raise SystemExit(main())
