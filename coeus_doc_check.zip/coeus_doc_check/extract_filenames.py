#!/usr/bin/env python3
"""从 COEUS 文档清单 Excel 中提取 Document Filename，按清单输出 5 个 JSON。

依赖: openpyxl (pip install openpyxl)

用法:
    python3 extract_filenames.py
    python3 extract_filenames.py --data-dir /path/to/coeus_doc_info --out-dir ./filenames
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.utils import column_index_from_string

# 每个 workbook 的提取配置：sheet 名、数据起始行、文件名列、标题列、文档编号列
WORKBOOKS = {
    "bea_sek": {
        "file": "BEA SEK_Master_20261111.xlsx",
        "sheets": [
            {"sheet": "SEK", "start_row": 4, "filename_col": "B", "title_col": "E"},
        ],
    },
    "citi_sek": {
        "file": "Citi SEK_Master_20261111.xlsx",
        "sheets": [
            {"sheet": "SEK", "start_row": 3, "filename_col": "B", "title_col": "E"},
        ],
    },
    "ifa": {
        "file": "BNC and IFA corner_Master_20261111.xlsx",
        "sheets": [
            {"sheet": "IFA", "start_row": 3, "filename_col": "C", "title_col": "D", "doc_code_col": "A"},
        ],
    },
    "bnc": {
        "file": "BNC and IFA corner_Master_20261111.xlsx",
        "sheets": [
            {"sheet": "BNC", "start_row": 3, "filename_col": "C", "title_col": "D", "doc_code_col": "A"},
        ],
    },
    "gc": {
        "file": "G&C_Master_20261111.xlsx",
        "sheets": [
            {"sheet": "Code", "start_row": 3, "filename_col": "E", "title_col": "D"},
            {"sheet": "Guideline", "start_row": 3, "filename_col": "E", "title_col": "D"},
            {"sheet": "Circulars on Regulatory Matters", "start_row": 3, "filename_col": "E", "title_col": "D"},
            {"sheet": "Circulars Updates on AML", "start_row": 3, "filename_col": "E", "title_col": "D"},
        ],
    },
}

SKIP_VALUES = {"", "(null)", "null", "none", "n/a"}


def clean(value) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    if text.lower() in SKIP_VALUES:
        return None
    return text


def extract_workbook(data_dir: Path, key: str, cfg: dict) -> dict:
    path = data_dir / cfg["file"]
    if not path.exists():
        raise FileNotFoundError(f"找不到 workbook: {path}")

    entries: list[dict] = []
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        for sheet_cfg in cfg["sheets"]:
            ws = wb[sheet_cfg["sheet"]]
            filename_idx = column_index_from_string(sheet_cfg["filename_col"])
            title_idx = column_index_from_string(sheet_cfg["title_col"]) if sheet_cfg.get("title_col") else None
            doc_code_idx = column_index_from_string(sheet_cfg["doc_code_col"]) if sheet_cfg.get("doc_code_col") else None
            used = [i for i in (filename_idx, title_idx, doc_code_idx) if i]
            max_col = max(used)

            start_row = sheet_cfg["start_row"]
            for offset, row_values in enumerate(
                ws.iter_rows(min_row=start_row, max_col=max_col, values_only=True)
            ):
                row_num = start_row + offset
                name = clean(row_values[filename_idx - 1])
                if name is None:
                    continue
                entries.append(
                    {
                        "file": name,
                        "list": sheet_cfg["sheet"],
                        "row": row_num,
                        "doc_code": clean(row_values[doc_code_idx - 1]) if doc_code_idx else None,
                        "title": clean(row_values[title_idx - 1]) if title_idx else None,
                    }
                )
    finally:
        wb.close()

    return {
        "workbook": cfg["file"],
        "workbook_key": key,
        "entries": entries,
        "summary": {"total": len(entries)},
    }


def main() -> int:
    script_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description="提取文档清单中的文件名，输出 5 个 JSON")
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=script_dir.parent / "coeus_doc_info",
        help="存放 4 个 Master xlsx 的目录 (默认: 同级 coeus_doc_info)",
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=script_dir / "filenames",
        help="JSON 输出目录 (默认: ./filenames)",
    )
    args = parser.parse_args()

    args.out_dir.mkdir(parents=True, exist_ok=True)
    failed = False
    for key, cfg in WORKBOOKS.items():
        try:
            payload = extract_workbook(args.data_dir, key, cfg)
        except Exception as exc:  # 单个文件失败不影响其他文件
            print(f"[FAIL] {cfg['file']}: {exc}")
            failed = True
            continue
        out_path = args.out_dir / f"{key}.json"
        out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        counts = ", ".join(
            f"{name} {sum(1 for e in payload['entries'] if e['list'] == name)}"
            for name in dict.fromkeys(e["list"] for e in payload["entries"])
        )
        print(f"[OK] {cfg['file']} -> {out_path.name}  (共 {payload['summary']['total']} 条: {counts})")

    print(f"\nJSON 已输出到: {args.out_dir}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
